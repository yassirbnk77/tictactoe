--import System.IO
import Text.Read (readMaybe)
import Tictactoe.Game
import Tictactoe.Fmt


-- TODO run
run :: Game -> IO ()
run g = do
    putStrLn $ "\n" <> fmtGame g
    case whoCanPlay g of
        Just player -> do
            putStrLn $ "Player: " ++ fmtPlayer player ++ ", enter move i j:"
            move <- getMove
            case move of
                Just (i, j) -> do
                    let newG = play i j g
                    if newG == g
                        then do
                            putStrLn "Move invalid"
                            run g
                        else run newG
                Nothing -> do
                    putStrLn "Input invalid"
                    run g
        Nothing -> putStrLn "\n Game over!"

getMove :: IO (Maybe (Int, Int))
getMove = do
    input <- getLine
    case words input of
        [xi, xj] -> case (readMaybe xi, readMaybe xj) of
            (Just i, Just j) -> return $ Just (i, j)
            _ -> return Nothing
        _ -> return Nothing


main :: IO ()
main = run newGameX